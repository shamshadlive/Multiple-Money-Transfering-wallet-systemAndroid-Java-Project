package com.shamshadlive.parentapplicationv4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddMoneyActivity extends AppCompatActivity {

    EditText edt_rechargeAmount;
    Button btn_topup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_money);

        edt_rechargeAmount=findViewById(R.id.edt_rechargeAmount);
        btn_topup=findViewById(R.id.btn_topup);

        btn_topup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();

                String ncurrentBalance = intent.getStringExtra("currentBalance");
                Log.e("currentBalance",ncurrentBalance);
                int icurrentBalance = Integer.parseInt(ncurrentBalance);
                int iTopupedMoney = Integer.parseInt(edt_rechargeAmount.getText().toString());

                int newBalance=iTopupedMoney+icurrentBalance;
                
             /*   // Storing data into SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putString("TopupedMoney", String.valueOf(newBalance));
                myEdit.commit();
*/
                Log.e("newBalance", String.valueOf(newBalance));

                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putString("TopupedMoney", String.valueOf(newBalance));
                myEdit.commit();



                Intent Nintent = new Intent(AddMoneyActivity.this,MainActivity.class);


                startActivity(Nintent);
            }
        });



    }
}