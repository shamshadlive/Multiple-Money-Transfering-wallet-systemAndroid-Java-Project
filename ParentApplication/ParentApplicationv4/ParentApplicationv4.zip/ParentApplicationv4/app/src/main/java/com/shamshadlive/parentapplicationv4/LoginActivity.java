package com.shamshadlive.parentapplicationv4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText edt_parentUsername,edt_parentPassword;
    Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edt_parentUsername=findViewById(R.id.edt_parentUsername);
        edt_parentPassword=findViewById(R.id.edt_parentPassword);
        btn_login=findViewById(R.id.btn_login);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username,password;

                username=edt_parentUsername.getText().toString();
                password=edt_parentPassword.getText().toString();

                if (username.equals("shamshad") && password.equals("12345")){

                    Intent sintent = new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(sintent);
                }
                else {
                    Toast.makeText(LoginActivity.this,
                            "Incorrect Username or Password", Toast.LENGTH_LONG).show();
                }

            }
        });



    }
}