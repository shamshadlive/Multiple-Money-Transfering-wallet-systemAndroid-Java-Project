package com.shamshadlive.parentapplicationv4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    ImageView imgbtn_addmoney,imgbtn_transactions;
    TextView txt_currentBalance;
    Button btn_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgbtn_addmoney=findViewById(R.id.imgbtn_addmoney);
        imgbtn_transactions=findViewById(R.id.imgbtn_transactions);
        txt_currentBalance=findViewById(R.id.txt_currentBalance);
        btn_logout=findViewById(R.id.btn_logout);




        imgbtn_addmoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,AddMoneyActivity.class);
                String currentBalance = txt_currentBalance.getText().toString();
                intent.putExtra("currentBalance", currentBalance);


                startActivity(intent);

            }
        });

        imgbtn_transactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

                String s1 = sh.getString("TopupedMoney", "");
                txt_currentBalance.setText(s1);
                Log.e("TopupedMoney", s1);

            }
        });



        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                    Intent sintent = new Intent(MainActivity.this,LoginActivity.class);
                    startActivity(sintent);


            }
        });

    }
}